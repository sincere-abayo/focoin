
// Get references to the elements
const accountLink = document.getElementById('account');
const modal = document.getElementById('modal');
const hideButton = document.getElementById('hide-button');
const claimButton = document.getElementById('claim-button');


// Function to show the modal
function showModal() {
    modal.classList.remove('hidden');
}

// Function to hide the modal
function hideModal() {
    modal.classList.add('hidden');
}

// Event listener for the link click
accountLink.addEventListener('click', function(event) {
    event.preventDefault(); // Prevent the default behavior of the link
    showModal();
});

// Event listener for the claim button to hide the modal
hideButton.addEventListener('click', hideModal);


// Disable the button
claimButton.disabled = true;

//winner program

// const playButton=document.getElementById('play-button');
// playButton.addEventListener('click',winnerProgram);

// function winnerProgram()
// {
    // const  programBlock=document.getElementById('winner-trade-program');
    // document.getElementById("play-button").addEventListener("click", function() {
        
    //     // Navigate to the #winner-trade-program div
    //     document.getElementById("winner-trade-program").style.display = "block";
    //     window.location.hash = "#winner-trade-program";
    //   });
    document.addEventListener("DOMContentLoaded", function() {
        // Get the "Play now" button
        const playButton = document.getElementById("play-button");
    
        // Add click event listener to the "Play now" button
        playButton.addEventListener("click", function() {
          // Show the #winner-trade-program div
          document.getElementById("winner-trade-program").style.display = "block";
    
          // Scroll smoothly to the #winner-trade-program section
          document.querySelector("#winner-trade-program").scrollIntoView({
            behavior: "smooth"
          });
        });
      });
// }

