
// Get references to the elements
const accountLink = document.getElementById('account');
const modal = document.getElementById('modal');
const hideButton = document.getElementById('hide-button');
const claimButton = document.getElementById('claim-button');


// Function to show the modal
function showModal() {
    modal.classList.remove('hidden');
}

// Function to hide the modal
function hideModal() {
    modal.classList.add('hidden');
}

// Event listener for the link click
accountLink.addEventListener('click', function(event) {
    event.preventDefault(); // Prevent the default behavior of the link
    showModal();
});

// Event listener for the claim button to hide the modal
hideButton.addEventListener('click', hideModal);


// Disable the button
claimButton.disabled = true;

